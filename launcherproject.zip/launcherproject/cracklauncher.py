import pygame
import json
import webbrowser
import os

# 1. SETUP ENVIRONMENT
os.chdir(os.path.dirname(os.path.abspath(__file__)))
pygame.init()
WIDTH, HEIGHT = 1000, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mirror Launcher - Classic Scroll Mode")

# COLORS
BG = (20, 20, 25)
CARD = (35, 35, 40)
ACCENT = (0, 150, 255)
WHITE = (255, 255, 255)
TEXT_GRAY = (180, 180, 180)

# FONTS
font_main = pygame.font.SysFont("Arial", 22, bold=True)
font_small = pygame.font.SysFont("Arial", 18)

# 2. LOAD DATA
master_list = []
try:
    with open('database.json', 'r') as f:
        master_list = json.load(f)
except Exception as e:
    print(f"Error loading JSON: {e}")

def run():
    current_tab = "Game"
    selected_item = None
    query = ""
    scroll_y = 0  # <--- New Scroll Variable
    running = True

    while running:
        screen.fill(BG)
        mouse_pos = pygame.mouse.get_pos()
        
        # Filter Logic
        results = [i for i in master_list if i.get('type') == current_tab and query.lower() in i['title'].lower()]
        
        if not selected_item and results:
            selected_item = results[0]

        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Mouse Wheel Scrolling
                if event.button == 4: # Scroll Up
                    scroll_y = min(0, scroll_y + 30)
                if event.button == 5: # Scroll Down
                    # Only scroll down if the list is longer than the screen
                    max_scroll = -(len(results) * 55 - 400) 
                    scroll_y = max(max_scroll, scroll_y - 30)

                # Tab Clicking (Stay fixed at top)
                if pygame.Rect(30, 20, 100, 40).collidepoint(event.pos): 
                    current_tab = "Game"
                    selected_item = None
                    scroll_y = 0 # Reset scroll on tab change
                if pygame.Rect(140, 20, 100, 40).collidepoint(event.pos): 
                    current_tab = "App"
                    selected_item = None
                    scroll_y = 0

                # List Item Clicking (Must account for scroll_y)
                y_pos = 130 + scroll_y
                for item in results:
                    # We check if the click is within the list area (to avoid clicking through header)
                    if y_pos > 120 and y_pos < HEIGHT - 50:
                        if pygame.Rect(30, y_pos, 550, 45).collidepoint(event.pos):
                            selected_item = item
                    y_pos += 55
                
                # Download Button Clicking
                if selected_item and pygame.Rect(630, 580, 320, 50).collidepoint(event.pos):
                    webbrowser.open(selected_item['link'])

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE: query = query[:-1]
                elif event.unicode.isprintable(): query += event.unicode
                scroll_y = 0 # Reset scroll when typing

        # --- DRAWING ---
        
        # 1. Draw List (Scrolled)
        # We define a "Clipping Rect" so the list doesn't overlap the header
        list_area = pygame.Surface((600, HEIGHT - 130))
        list_area.fill(BG)
        
        y_draw = scroll_y
        for item in results:
            rect = pygame.Rect(0, y_draw, 550, 45)
            color = (50, 50, 60) if item == selected_item else CARD
            pygame.draw.rect(list_area, color, rect, border_radius=5)
            list_area.blit(font_small.render(item['title'], True, WHITE), (15, y_draw + 12))
            y_draw += 55
            
        screen.blit(list_area, (30, 130))

        # 2. Draw Sidebar (Fixed)
        if selected_item:
            pygame.draw.rect(screen, CARD, (610, 80, 360, 580), border_radius=10)
            screen.blit(font_main.render(selected_item['title'], True, WHITE), (630, 110))
            screen.blit(font_small.render(f"Developer: {selected_item['dev']}", True, TEXT_GRAY), (630, 150))
            
            size_val = selected_item.get('size', 'Standard Install')
            screen.blit(font_small.render(f"Info: {size_val}", True, ACCENT), (630, 180))
            
            if "Torrent" in size_val:
                pygame.draw.rect(screen, (80, 30, 30), (630, 220, 320, 60), border_radius=5)
                screen.blit(font_small.render("⚠️ TORRENT FILE", True, (255, 100, 100)), (640, 230))
                screen.blit(font_small.render("Needs qBitTorrent.", True, WHITE), (640, 250))

            dl_rect = pygame.Rect(630, 580, 320, 50)
            pygame.draw.rect(screen, ACCENT, dl_rect, border_radius=8)
            screen.blit(font_main.render("DOWNLOAD", True, WHITE), (730, 592))

        # 3. Draw Header (Fixed at top so it covers the scrolling list)
        pygame.draw.rect(screen, BG, (0, 0, WIDTH, 130)) # Header Background
        
        pygame.draw.rect(screen, ACCENT if current_tab == "Game" else CARD, (30, 20, 100, 40), border_radius=5)
        screen.blit(font_small.render("GAMES", True, WHITE), (45, 30))
        
        pygame.draw.rect(screen, ACCENT if current_tab == "App" else CARD, (140, 20, 100, 40), border_radius=5)
        screen.blit(font_small.render("APPS", True, WHITE), (165, 30))

        pygame.draw.rect(screen, CARD, (30, 80, 550, 35), border_radius=5)
        search_txt = f"Search: {query}" if query else "Scroll or type to search..."
        screen.blit(font_small.render(search_txt, True, TEXT_GRAY), (40, 87))

        pygame.display.flip()

run()